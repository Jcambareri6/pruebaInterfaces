class juego {
    constructor(canvas){

    }
}