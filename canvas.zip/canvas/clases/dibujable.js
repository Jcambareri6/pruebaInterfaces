 class dibujable{
    constructor(posX,posY,ctx){
        this.posX=posX;
        this.posY=posY;
        this.ctx=ctx;
    }
    draw(){
        return 0;
    }
 }